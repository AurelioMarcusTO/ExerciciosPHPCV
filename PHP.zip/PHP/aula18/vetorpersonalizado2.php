<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
		<pre>
	<?php
		$v = array ( "nome" => "Aurelio" ,
					 "idade" => 42 ,
					 "peso" => 74 ,
					 "fuma" => "sim" ) ;
		foreach($v as $k => $c) {
			echo "O campo $k possui o conteudo $c <br/>" ;
		}			 
					 
		 
     
	?>
	</pre>
    </div>
</body>
</html>