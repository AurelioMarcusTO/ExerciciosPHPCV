<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
		<pre>
	<?php
		$v = array ( 3=>5 ,
					 1=>9 ,
					 7=>8 ,
					 5=>7) ;
		$v[4] = 6 ;
		unset($v[1]) ;			 
		print_r($v) ;			 
		 
     
	?>
	</pre>
    </div>
</body>
</html>