<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<pre>
	<?php
		$m = array ( array (6 ,4) ,
					 array (4, 9) ,
					 array (3, 2)) ;
		$m[0] [1] = $m[2] [0] ; //linha 0 coluna 1 recebe linha 2 coluna 0			 
		print_r ($m) ;			 
		 
     
	?>
	</pre>
    </div>
</body> 
</html>