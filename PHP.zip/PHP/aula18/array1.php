<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<pre>	
	<?php
	
		$n = array(3, 5, 8, 2) ;
		$n[] = 7 ;
		print_r($n) ;
		 
     
	?>
	</pre>
    </div>
</body>
</html>