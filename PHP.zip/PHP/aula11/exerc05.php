<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
	  $i = 1 ;
	  while ($i <= 5) {
		  
		  $valor = isset ($_GET["v" . $i]) ? $_GET["v".$i] : 0 ;
		  echo "Valor $i : " . $valor . "<br/>" ;
		  $i += 1;
	  }  

	  
		 
     
	?>
    </div>
</body>
</html>