<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
	  $i = 1 ;
	  while ($i <= 5) {
		  
		  $v = "num" . $i ;
		  $url = "v".$i ;
		  $$v = isset ($_GET[$url]) ? $_GET[$url] : 0 ;		  
		  $i += 1;
	  }  
	  $i = 1 ;
	  while ($i <= 5) {
		  $v = "num" . $i ;
		  echo "Valor $i : " . $$v . "<br/>" ;
		  $i += 1 ;
	  }

	  
		 
     
	?>
    </div>
</body>
</html>