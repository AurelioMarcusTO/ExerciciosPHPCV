<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
		$i = isset ($_GET["ini"]) ? $_GET["ini"] : 0 ;
		$t = isset ($_GET["term"]) ? $_GET["term"] : 0 ;
		$in = isset ($_GET["increm"]) ? $_GET["increm"] : 0 ;
		
		while ($i <= $t) {
			echo $i . " , ";
			$i += $in ;
		}
		while ($i >= $t) {
			echo $i . " , " ;
			$i -= $in ;
		}
		 
     
	?>
	<br/><a href="javascript:history.go(-1)" class="botao">Voltar</a>
    </div>
</body>
</html>