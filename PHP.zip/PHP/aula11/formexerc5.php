<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>

	<form method="get" action="exerc05.1.php">
		<?php
		$c = 1;
		while ($c <= 5) {
			echo "Valor $c : <input type='number' name='v$c' max='100' min='0' value='0'/><br/>" ;
			$c += 1 ;
		}
		?>	
            <input type="submit" value="Enviar" class="botao"/>
    </form>
	
    </div>
</body>
</html>