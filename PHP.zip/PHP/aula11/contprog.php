<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Contagem Progressiva</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
		$c = 1 ;
		while ($c <= 10) {
			echo $c . "<br/>" ;
			$c += 1 ; // $c ++ ; $c = $c + 1 ;
		}
		 
     
	?>
    </div>
</body>
</html>