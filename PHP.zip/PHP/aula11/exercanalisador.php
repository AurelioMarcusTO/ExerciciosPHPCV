<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
	  $i = 1 ;
	  while ($i <= 5) {
		  
		  $v = "num" . $i ;
		  $url = "v".$i ;
		  $$v = isset ($_GET[$url]) ? $_GET[$url] : 0 ;		  
		  $i += 1;
	  }  
	  $i = 1 ;
	  $soma = 0;
	  while ($i <= 5) {
		  $v = "num" . $i ;
		  echo "Valor $i : " . $$v . "<br/>" ;
		  $soma += $$v ;
		  if ($$v % 2 == 0) {
			$par[$i] = $$v ;
		  }
		  if ($$v == 0 || $$v % 2 ==1) {
			$impar[$i] = $$v ;
		  }
		  $i += 1 ;
	  }
	  echo "Os valores pares digitados são : " ;
	   foreach($par as $p){echo "$p , " ;}  ;
	  echo "<br/>Os valores impares digitados são : " ;
	   foreach($impar as $im){echo "$im , " ;} ;
	  echo "<br/>A soma dos valores é : $soma" ;
	  
		 
     
	?>
    </div>
</body>
</html>