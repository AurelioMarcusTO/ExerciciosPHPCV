<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Operadore Aritmeticos Soma</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
    <?php	
        $n1 = 2;
        $n2 = 3;
        $s = $n1 + $n2;
        echo "O resultado da soma é $s";

	?>
    </div>
</body>
</html>