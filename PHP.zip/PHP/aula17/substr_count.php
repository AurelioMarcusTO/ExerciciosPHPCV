<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
		$frase = "Estou aprendendo PHP no Curso em Video de PHP" ;
		$cont = substr_count($frase, "PHP") ;
		print("PHP encontrado $cont vezes") ;
		 
     
	?>
    </div>
</body>
</html>