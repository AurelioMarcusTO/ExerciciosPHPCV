<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
		$nome = "aurelio marcus" ;
		$nome2 = ucwords($nome) ;
		echo "Seu nome é $nome2" ;
		 
     
	?>
    </div>
</body>
</html>