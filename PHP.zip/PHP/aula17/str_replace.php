<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
		$frase = "Gosto de estudar Matemática !!!" ;
		$novafrase = str_replace("Matemática", "PHP", $frase) ;
		echo "$novafrase" ;
		 
     
	?>
    </div>
</body>
</html>