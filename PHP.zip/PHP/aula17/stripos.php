<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
		$frase = "Estou aprendendo PHP" ;
		$pos = stripos($frase, "php") ;
		print "$frase <br/> A posição das palavra PHP esta $pos" ;
		 
     
	?>
    </div>
</body>
</html>