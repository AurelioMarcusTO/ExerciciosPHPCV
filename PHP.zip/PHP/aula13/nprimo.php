<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		span {
			color: red ;
			font-weight: bold ;
		}
	</style>
</head>

<body>
	<div>
	<?php
		$c = 1 ;
		$div = 0 ;
		$n = isset ($_GET["num"]) ? $_GET["num"] : 0 ;

		echo "<h2>Analisando o número <span>$n</span></h2><br/>" ;
		echo "O numero $n é multiplo de :" ;
		for ($c = 1 ; $c <= $n ; $c += 1) {
			$mod = $n % $c ;
			if ($mod == 0 && $c >= 1) {
				echo "<span>$c</span>   " ;
				$div++ ;
			}
		}
		echo "<br/>O número $n possui <span>$div</span> divisores";
		if ($div == 2) {
			echo "<br/>$n <span>é número primo !</span>" ;
		} 
		else {
			echo "<br/>$n <span>não é número primo !</span>" ;
		}
	?>
	<br/><a href="Numeroprimo.html" class="botao">Voltar</a>
    </div>
</body>
</html>