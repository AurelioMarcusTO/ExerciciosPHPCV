<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Tabuada</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		div {
			padding: 20px ;
			margin: 50px ;
		}
	</style>
</head>

<body>
	<div>
		<form method="get" action="tab.php">
		<select name="num">
	<?php
        for ($c = 1 ; $c <= 10 ; $c += 1) {
			echo "<option>$c</option>" ;
		}
	?>
	    </select>
		<input type="submit" value="Tabuada" class="botao"/>
	   </form>
    </div>
</body>
</html>