<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		div {
			padding: 30px ;
			margin: 50px ;
			width: 450px ;
			height: 300px ;
			
		}
	</style>
</head>

<body>
	<div>
	<?php
		$n = ($_GET["num"]) ? $_GET["num"] : 1 ;
		for ($c = 1 ; $c <= 10 ; $c += 1) {
			$r = $n * $c ;
			echo "$n X $c = $r <br/>" ;
		}
	     
	?>
	<br/><a href="javascript:history.go(-1)" class="botao">Voltar</a>
    </div>
</body>
</html>