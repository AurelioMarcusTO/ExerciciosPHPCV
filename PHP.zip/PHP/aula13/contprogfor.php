<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
        for ($c = 1 ; $c <= 10 ; $c += 1) {
			echo $c ." " ;
		}
		 echo "<br/>" ;
		 for ($c = 10 ; $c >= 1 ; $c -= 1) {
			 echo $c . " " ;
		 }
		 echo "<br/>" ;
		 for ($c = 0 ; $c <= 50 ; $c += 5) {
			 echo $c . " " ;
		 }
		 echo "<br/>" ;
		 for ($c = 50 ; $c >= 0 ; $c -= 5) {
			 echo $c . " " ;
		 }
     
	?>
    </div>
</body>
</html>