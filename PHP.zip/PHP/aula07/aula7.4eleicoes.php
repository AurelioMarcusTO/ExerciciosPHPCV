<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Eleições</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
		$ano = $_GET["ano"];
		$idade = 2020 - $ano;
		echo "Quem nasceu em $ano tem idade de $idade";
		$tipo = ($idade >= 18 && $idade < 65) ? "OBRIGATORIO" : "NAO OBRIGATORIO";
		echo "<br/>O seu voto é $tipo";
		 
     
	?>
    </div>
</body>
</html>