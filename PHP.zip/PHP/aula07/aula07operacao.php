<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Operações</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
		$n1 = $_GET["a"];
		$n2 = $_GET["b"];	
		$tipo = $_GET["op"];
		echo "Os valores digitados foram $n1 e $n2.";
		$r = ($tipo == "s") ? $n1+$n2 : $n1*$n2;
		echo "<br/>O resultado será $r";
		 
     
	?>
    </div>
</body>
</html>