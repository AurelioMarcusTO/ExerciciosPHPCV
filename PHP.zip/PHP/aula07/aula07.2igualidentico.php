<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Iguais ou Idênticos</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
        $a = 3;
        $b = "3";
        $r = ($a == $b) ? "SIM" : "NAO";
        echo "As variaveis A e B são iguais ? $r";
        $r2 = ($a === $b) ? "SIM" : "NAO";
        echo "<br/>As variaveis A e B são identicas ? $r2";

		 
     
	?>
    </div>
</body>
</html>