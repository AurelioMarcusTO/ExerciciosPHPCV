<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Médias de alunos</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
        $nota1 = $_GET["n1"];
        $nota2 = $_GET["n2"];
        $m = ($nota1 + $nota2)/2;
        echo "A média entre $nota1 e $nota2 é $m";
        $sit = ($m<6) ? "REPROVADO" : "APROVADO";
        echo "<br/>O aluno foi $sit";

		 
     
	?>
    </div>
</body>
</html>