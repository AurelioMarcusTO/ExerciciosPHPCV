<?php
	function ola() {
		echo "<h1>Olá, Mundo !</h1>" ;
	}

	function mostraValor($v) {
		$v = $v + 3 ;
		echo "<h2>Acabei de receber o valor de V : $v </h2>" ;
	}
?>