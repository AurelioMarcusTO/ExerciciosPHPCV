<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
		include "funcoes.php" ;
		echo "<h1>Testando novas funções !</h1>" ;
		ola() ;
		$a = 4 ;
		mostraValor($a) ;
		echo "<h2>Recebi o valor de A : $a</h2>";
		echo "<h2>Finalizando programa ...</h2>";
		 
     
	?>
    </div>
</body>
</html>