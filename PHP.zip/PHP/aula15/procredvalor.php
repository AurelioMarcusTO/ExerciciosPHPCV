<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
        function teste ($x) {
			$x = $x + 2 ;
			echo "O valor de X é $x" ;

		}

		$a = 3 ;
		teste ($a) ;
		echo "<p>O valor de A é $a</p>" ;
		 
     
	?>
    </div>
</body>
</html>