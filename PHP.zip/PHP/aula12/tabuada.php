<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
		$v = isset ($_GET["val"]) ? $_GET["val"] : 1 ;
		$c = 0 ;
		$res = 0 ;
		echo "Mostrando a tabuada do $v <br/>" ;
		do {
			$res = $v * $c ;
			echo "$v X $c = $res <br/>" ;
			$c += 1 ;
			
		} while ($c <= 10)
		 
     ?>
	<br/><a href="javascript:history.go(-1)" class="botao">Voltar</a>
    </div>
</body>
</html>