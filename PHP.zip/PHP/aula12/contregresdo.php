<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
	  $c = 10 ;
	  do {
		  echo $c . " " ;
		  $c -= 1 ;
		}while ($c >= 0);  
		 
     
	?>
    </div>
</body>
</html>