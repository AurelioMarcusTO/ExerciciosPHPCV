<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Primeiro exemplo PHP</title>
	<style>
		h2 {
			color: #80a2ff;
			text-shadow: 1px 1px 1px black;
		}
	</style>
</head>

<body>
	<h1>Oi Mãe ....</h1>
	<?php	echo "<h2>Feliz Dia das Mães ..!!!!</h2>";
	?>

</body>
</html>