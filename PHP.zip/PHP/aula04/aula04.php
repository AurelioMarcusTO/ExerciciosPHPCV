<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Escrevendo o nome e idade</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
    <?php	
        $idade = 41;
        $nome = "Aurelio";
        echo $nome." tem ".$idade." anos. ";
        echo "$nome tem $idade anos !";
	?>
    </div>
</body>
</html>