<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
		echo "Formula de Fibonacci : <br/><br/>" ;
		function fibo(&$a, &$b) {
			$c = $a + $b ;
			echo $c. " " ;
			$a = $b ;
			$b = $c ;
		}
		$t1 = 0 ;
		echo $t1 . " " ;
		$t2 = 1 ;
		echo $t2 . " " ;
		for ($c = 3 ; $c <= 15 ; $c += 1) {
			fibo($t1, $t2) ;
		}
		?>
</body>
</html>