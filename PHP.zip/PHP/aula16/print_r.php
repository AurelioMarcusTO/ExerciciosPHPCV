<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Uso do print_r</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
		$v[0] = 4 ;
		$v[1] = 8 ;
		$v[2] = 3 ;
		print_r ($v) ;
		$v2 = array (3, 7, 6, 2, 1, 9) ;
		print_r ($v2) ;
		var_dump ($v) ;
		var_export($v2) ;		 
     
	?>
    </div>
</body>
</html>