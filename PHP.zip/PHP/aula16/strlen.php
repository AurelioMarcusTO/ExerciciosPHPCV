<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Uso do strlen</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
		$txt = "Aurelio Marcus T. de Oliveira" ;
		echo "Seu texto é : $txt<br/>" ;
		$tamanho = strlen($txt) ;
		echo "O tamanho da sua string ou texto é $tamanho" ;
		 
     
	?>
    </div>
</body>
</html>