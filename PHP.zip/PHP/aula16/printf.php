<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Uso do printf</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
	   $p = "Leite" ;
	   $pr = 4.5 ;
	   printf ("O %s custa R$ %.2f ", $p, $pr) ; 
		 
     
	?>
    </div>
</body>
</html>