<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
	   $nome = "   Aurelio Marcus   " ;
	   echo ($nome) . "<br/>" ;
	   echo (strlen($nome)) . "<br/>" ;
	   $novo = trim($nome) ;
	   echo ($novo) . "<br/>" ;
	   echo (strlen($novo)) ; 
		 
     
	?>
    </div>
</body>
</html>