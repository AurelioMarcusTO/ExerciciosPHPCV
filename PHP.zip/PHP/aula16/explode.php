<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
		$site = "Curso em Video" ;
		$vetor = explode(" ", $site) ;
		print_r ($vetor) ;
		 
     
	?>
    </div>
</body>
</html>