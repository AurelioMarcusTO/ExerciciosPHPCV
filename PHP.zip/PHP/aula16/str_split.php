<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
		$nome = "Aurelio Marcus" ;
		$vetor = str_split($nome) ;
		print_r($vetor) ;
		 
     
	?>
    </div>
</body>
</html>