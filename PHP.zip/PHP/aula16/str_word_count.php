<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
		$frase = "Eu vou estudar PHP" ;
		echo "Sua frase é : $frase<br/>" ;
		$cont = str_word_count($frase, 2) ;
		echo "é o número de palavras " . print_r($cont) ;
		 
     
	?>
    </div>
</body>
</html>