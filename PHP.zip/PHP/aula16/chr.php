<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
	   $letra = chr(67) ;
	   echo "A letra de codigo 67 é $letra" ; 
		 
     
	?>
    </div>
</body>
</html>