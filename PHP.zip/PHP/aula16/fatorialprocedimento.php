<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
        function facto($v) {
			$r = 1 ;
			for ($c = 1;$c <= $v;$c += 1) {
				$r = $r * $c ;
				
			}
			return $r ;
		}
		$n = isset ($_GET["num"]) ? $_GET["num"] : 1 ;
		$f = facto($n) ;
		echo "O fatorial de $n é igual a $f ." ;
		 
     
	?>
    </div>
</body>
</html>