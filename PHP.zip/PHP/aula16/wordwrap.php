<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Uso do worlwrap</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
        $t = "Aqui temos um texto gigante criado pelo PHP e vai mostrar o funcionamento da função wordwrap . " ;
		$r = wordwrap ($t, 5, "<br/>\n", true) ;
		echo $r ; 
     
	?>
    </div>
</body>
</html>