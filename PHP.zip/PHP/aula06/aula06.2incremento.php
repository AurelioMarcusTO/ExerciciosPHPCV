<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Incrementos</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		h2 {
            font: 18pt Arial;
            color: #171559;
            font-weight: bold;

        }
	</style>
</head>

<body>
	<div>
    <?php	
        $atual = $_GET["aa"];
        echo "<h2>O ano atual é $atual</h2>";
        $anopos = ++$atual ; // incremento
        echo "<h2>O ano posterior é $anopos</h2>";
        $anoant = $atual - 2;
        echo "<h2>O ano anterior é  $anoant</h2>";
     

	?>
    </div>
</body>
</html>