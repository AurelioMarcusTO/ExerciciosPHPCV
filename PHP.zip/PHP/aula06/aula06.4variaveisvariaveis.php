<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Variáveis de Variáveis</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
    <?php	
        $x = "primeira";
        $$x = "segunda";
        echo "O conteúdo da variavel X é $x";
        echo "<br/>A variavel primeira criada recebeu o valor $primeira";
     

	?>
    </div>
</body>
</html>