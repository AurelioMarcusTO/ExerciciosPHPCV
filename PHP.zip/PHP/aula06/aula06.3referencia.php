<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Referências</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
    <?php	
        $a = 3 ;
        $b = &$a ;
        $b += 5 ;
        echo "A variavel A vale $a";
        echo "<br/>A varialvel B vale $b";
     

	?>
    </div>
</body>
</html>