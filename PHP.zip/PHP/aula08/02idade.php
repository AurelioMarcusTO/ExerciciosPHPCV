<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		div {
            font-family: Arial, sans serif;
            font-size: 18pt;
            text-shadow: 1px 1px 1px #000000;
            color:#1b1919;
            padding: 50px;
		}
		fieldset {
	        border-color: #cecece;
	        margin: 20px;
            width: 500px;
        }
	</style>
</head>

<body>
	<div>
		<fieldset>
	<?php
		$nome = isset ($_GET["nome"]) ? $_GET["nome"] : "[nao informado]";
		$ano = isset ($_GET["ano"]) ? $_GET["ano"] : 0 ;
		$sexo = isset ($_GET["sexo"]) ? $_GET["sexo"] : "[sem sexo]";
		$idade = date("Y") - $ano;
		echo "$nome tem $idade anos e é do sexo $sexo."
		     
	?>
	</fieldset>
	<br/><a href="formulario2.html">Voltar</a>
    </div>
</body>
</html>