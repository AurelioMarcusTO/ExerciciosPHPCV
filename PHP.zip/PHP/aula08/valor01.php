<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Dados formulario</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
	   $valor = $_GET["v"] ;
	   $rq = sqrt($valor);
	   echo "Digitou o valor: $valor";
	   echo "<br/>A raiz quadrada do valor é: " . number_format($rq,2);
		     
	?>
	<a href="formulario.html">Voltar</a>
    </div>
</body>
</html>