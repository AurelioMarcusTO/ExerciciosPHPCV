<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8"/>
	<title>Curso em Video</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
	<style>
		
	</style>
</head>

<body>
	<div>
	<?php
        function soma ($a, $b) {
			$s = $a + $b ;
			return $s ;
		}
		
		$x = 9 ;
		$y = 15 ;
		$r = soma ($x, $y) ;
		echo "A soma entre $x e $y é igual a $r." ;
		
	?>
    </div>
</body>
</html>